<?php
$conn = mysqli_connect("localhost", "root", "", "ac");
if(!$conn){
    die("Something went wrong!!!");
}
?>