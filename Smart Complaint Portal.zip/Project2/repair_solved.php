
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Student Login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='login_page.css'>
    <script src='main.js'></script>
</head>
<body>
<center><h1 style="color: black;">Repair Details</h1></center>
<form action="" method="post">
    <div class="login-box">
      <center><img src="vvitlogo.jpg"></center>
      <br>
      
          <div class="user-box">
            <input type="text" name="room_no" required="" placeholder="Room Number">
          </div>
          
          <div class="user-box">
            <input type="text" name="repairdesc" required="" placeholder="A/C Repair Details">
          </div>

          <div class="user-box">
            <input type="date" name="repairdate" required="" style="color:#7b7a7a">
            <label class="rdate">Date</label>
          </div>
          
         <center> <button type="submit" name="insert" class="login_btn" style="width:40%">SUBMIT</button></center>
           &emsp;&emsp; 
           
          <br>
            <div><label style="font-size:18px;color:#7b7a7a;font-weight:bold;">
            <center>  <a href="ground.php" style="text-decoration:underline;">Go back to Home</a>
            </center></label>
            </div>
      </div>

      
      </form>
      

</body>
</html>